package service;

import java.util.List;
import java.util.Scanner;
import java.util.ArrayList;
import bean.Student;

public class StudentService {

	static List<Student> lst  = new ArrayList();
	static {
		lst.add(new Student(1,"v", 81));
	}
	Student std;
	public void getinfo(Student[] arr) {
		// TODO Auto-generated method stub
		for (int i = 0 ; i<arr.length ; i++) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter roll-no");
		int id = sc.nextInt();
		System.out.println("Enter name");
		String nm = sc.next();
		System.out.println("enter marks");
		float mark = sc.nextFloat();
		
		 arr[i] = new Student (id,nm,mark);
		
		}
	}

	public void show(Student [] arr ) {
		// TODO Auto-generated method stub
		for (int i = 0 ; i<arr.length ; i++) {
			System.out.println(arr[i]);
		}
			
	}

	public void comparemark(Student[] arr) {
		for(Student s:arr) {
		if(s.getMarks()==98) {
			System.out.println(s);
		}
		}
	}

	public void compare(Student [] arr) {
		for(Student s:arr) {
			if(s.getMarks() >=60 && s.getMarks() < 70) {
				System.out.println(s);
			}
			}
	}

}
