package test;


import bean.Student;
import service.StudentService;

public class TestStudent {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Student [] arr = new Student [5];
		
		StudentService ss = new StudentService();
		
		ss.getinfo(arr);
		ss.comparemark(arr);
		System.out.println("------ between 60 to 70 ---------");
		ss.compare(arr);
		System.out.println("==========Arr ==============");
		ss.show(arr);
		
	}

}
