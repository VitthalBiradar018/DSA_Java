package service;



public class Stack {
		public Node top;
		 class Node{
			  char data;
			  Node next;
			 public  Node(){
				   this.next=null;
			   }
			   
			   public Node(char c) {
				   this.data=c;
				   this.next=null;
			   }
			   
		  }
		
		 public void push(char c) {
			 Node node = new Node(c);
				if(top==null) {
					top=node;
				}
				else {
					node.next=top;
					top=node;
				}

		 }
		 public boolean isEmpty() {
			 return top==null;
		 }
		 
		 public void pop() {
			 if(top==null) {
				  System.out.println("List is Empty");
				  
			  }
			  else {
				  Node temp=top;
				  top=temp.next;
				  temp.next=null;
				  temp=null;
				  }
			  }
		 public void dispplay() {
			 if(top==null) {
				  System.out.println("List is Empty");
			  }
			  else { Node temp = top;
				while(temp!=null) {
					System.out.println(temp.data+" ");
					temp=temp.next;
				}
				  
			  }
		 }
		 
		 
}
