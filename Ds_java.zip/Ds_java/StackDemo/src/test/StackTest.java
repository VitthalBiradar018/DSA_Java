package test;

import service.Stack;

public class StackTest {

	public static void main(String[] args) {

		Stack st =new Stack();

		String s="(([]{}))";
		
		for(int i=0;i<s.length();i++) {
			if(s.charAt(i)=='(') {
				st.push('(');
			}
			else if(s.charAt(i)=='[') {
				st.push('[');
			}
			else if(s.charAt(i)=='{') {
				st.push('{');
			}
		
			else if(s.charAt(i)==')' || s.charAt(i)==']'|| s.charAt(i)=='}') {
				if(st.isEmpty()) {
					System.out.println("ImBalance String");
					return;
				}
				st.pop();
			}
		}
		st.dispplay();
		
		if(st.isEmpty()) {
			System.out.println("Balanced String of Parenthisis");
		}
		else {
			System.out.println("ImBalance String");
		}
		
		
	}

}
