package test;

import service.arrayservice;
import java.util.Scanner;


public class array {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter size");
		int size = sc.nextInt();
		int [][] arr = new int [size][size];
		
		arrayservice.acceptdata(arr);
		arrayservice.display(arr);
		arrayservice.findmax(arr);
		arrayservice.findoddmax(arr);
	}

}
