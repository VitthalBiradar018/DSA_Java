package service;
import java.util.Scanner;
public class arrayservice {

	public static void acceptdata(int[][] arr) {
		Scanner sc = new Scanner (System.in);
		// TODO Auto-generated method stub
		for (int i = 0; i<arr.length ; i++) {
			for (int j = 0 ; j<arr.length ; j++) {
				System.out.println("enter values");
				arr[i][j] = sc.nextInt();
			}
		}
	}

	public static void display(int[][] arr) {
		// TODO Auto-generated method stub
		for (int i = 0 ; i<arr.length ; i++) {
			for (int j = 0 ; j<arr.length ; j++) {
				System.out.print(arr[i][j] +" ");
			}
			System.out.println();
		}
	}


	public static void findmax(int[][] arr) {
		// TODO Auto-generated method stub
		int max = arr[0][0];
		for (int i = 0; i<arr.length ;i++) {
			for (int j = 0; j<arr.length ; j++) {
				if (arr[i][j]>max) {
					max = arr[i][j];
				}
			}
		}
		System.out.println("Max Value :- " +max);
		
	}

	public static void findoddmax(int[][] arr) 
	{
		// TODO Auto-generated method stub
		int max = arr[0][0];
		int oddmax = 0;
//		if(arr[0][0]%2 != 0) 
//		{
		for (int i = 0 ; i< arr.length ; i++) 
		{
			for ( int j = 0 ; j<arr.length ; j++) 
			{
				if (max<arr[i][j])
				{
					max = arr[i][j];
					if(arr[i][j]%2 != 0) {
						//System.out.println("odd max ;- " + arr[i][j]);
						oddmax = arr[i][j];
					}
//					else
//						System.out.println("odd not found");
						
				}
		}
		}
		System.out.println("odd max  = :- "+ oddmax);
	}
//		else {
//			max = arr[]
//		}
//		
//	}

}
