package service;

import java.util.Scanner;

public class servicesort {
	public static void accept(int [] arr) {
		Scanner sc = new Scanner(System.in);
		for (int i = 0 ; i<arr.length ; i++) {
			System.out.println("Enter Values");
			arr[i]=sc.nextInt();
		}
		
	}

	public static void display(int[] arr) {
		for (int i =0 ; i<arr.length ; i++) {
			System.out.print(arr[i] + " ");
		}
		System.out.println();
	}

	
	
	public static void heapsort(int[] arr) {
		int end= arr.length;
		
		for (int i = end/2-1 ; i>0; i--) {
			maxheap(arr,i,end);
		}
		
		for (int i = end -1 ; i>=0 ; i--) {
			int remp = arr[0];
			arr[0] = arr[i];
			arr[i]= remp;
			maxheap(arr,i,0);
		}
	}

	private static void maxheap(int[] arr, int i, int end) {
		int largest = i;
		int left = 2*i+1;
		int right = 2*i+2;
		
		if (end> left && arr[left]>arr[largest]) {
			largest = arr[left];
		}
		if (end> right && arr[right]>arr[largest] ) {
			largest = arr[right];
		}
		if(largest != i) {
			int temp = arr[i];
			arr[i] = largest;
			largest = temp;
			maxheap(arr, largest, end);
		}
	}

	public static void quick(int[] arr, int start, int end) {
		if(start<end)
		{
		int p = partion(arr,start,end);
		
		quick(arr,start,p-1);
		
		quick(arr,p+1,end);
		
		}
	}
	

	private static int partion(int[] arr, int start, int end) {
		int pivote = start;
		int i=start;
		int j=end;
		while (i<j) 
		{
			while(i<end && arr[i]<=arr[pivote]) 
				i++;
			while(j>start && arr[j]>arr[pivote])
				j--;
			if(i<j)
			{
				int temp=arr[i];
				arr[i]=arr[j];
				arr[j]=temp;
				
			} 
			
		}
		int temp=arr[pivote];
		arr[pivote]=arr[j];
		arr[j]=temp;
		
		display(arr);
		System.out.println("\n pivot "+arr[j]+" is placed at" +j +" position");
		return j;
	}

	public static int[] countsort(int[] arr) {
		int max = findmax(arr);
		int [] count = new int [max+1];
		for (int i = 0 ; i<count.length; i++) {
			count[i] =0;
		}
		for (int i = 0; i <arr.length ; i++) {
			count[arr[i]]++;
		}
		for (int  i = 1; i<count.length ; i++) {
			count[i] = count[i-1] + count[i];
		}
		int [] output = new int [arr.length];
		for(int i = 0; i<output.length ;i++) {
			output[count[arr[i]]-1]=arr[i];
			count[i]--;
		}
		return (output);
		}

	private static int findmax(int[] arr) {
		int max = arr[0];
		for(int i = 0; i<arr.length ; i++) {
			if(arr[i]>max) {
				max = arr[i];
			}
	}
		return max;
	}

}
