package test;

import service.servicesort;

public class testsort {

	public static void main(String[] args) 
	{
		int [] arr = new int [6];
		
		servicesort.accept(arr); 
		servicesort.display(arr);
	//	servicesort.quick(arr,0 ,arr.length-1);
	//servicesort.heapsort(arr);
		
	int[] arr1=	servicesort.countsort(arr);
		servicesort.display(arr1);
	

	}

}
