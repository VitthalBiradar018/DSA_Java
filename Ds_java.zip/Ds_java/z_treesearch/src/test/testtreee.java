package test;

import service.trees;

public class testtreee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		trees t = new trees();
		t.insert(10);
		t.insert(20);
		t.insert(56);
		t.insert(78);
		t.insert(2);
		
		t.indisplay();
		System.out.println("---------------");
		t.predisplay();
		System.out.println("-----------------");
		t.postdisplay();
	
		
	}

}
