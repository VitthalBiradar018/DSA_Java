package service;

public class trees {

	Node root;
		public trees() {
			root = null;
		}
		
	class Node {
		int data;
		Node left;
		Node right;
		
		public Node (int val) {
			data= val;
			left =null;
			right = null;
		}
	}
	
	public void insert(int val) {
		root = insertval(root ,val);
	}

	private Node insertval(Node root, int val) {
		
		Node newnode = new Node(val);
		if(root == null) {
			root = newnode;
			return root;
		}
		else {
			if(val < root.data) {
				root.left = insertval(root.left,val) ;
			}
			else {
				root.right = insertval(root.right,val);
			}
		}
		return root;
	}
	
	public void indisplay() {
		inorder(root);
	}
	public void inorder(Node root) {
		if(root != null) {
			inorder(root.left);
			System.out.println(root.data);
			inorder(root.right);
		}
	}
	
	public void predisplay()
	{
		preorder(root);
	}

	private void preorder(Node root) {
		// TODO Auto-generated method stub
		if(root!=null) {
			System.out.println(root.data);
			preorder(root.left);
			preorder(root.right);
		}
		
	}
	public void postdisplay()
	{
		postorder(root);
	}

	private void postorder(Node root) {
		// TODO Auto-generated method stub
		if(root!=null) {
		postorder(root.left);
		postorder(root.right);
		System.out.println(root.data);
	}
	}
	
}
