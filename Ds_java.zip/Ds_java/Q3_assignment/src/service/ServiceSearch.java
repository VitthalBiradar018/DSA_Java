package service;

import java.util.Scanner;

public class ServiceSearch {
	static int iter = 0;
	public static void linearsearch(int[] arr, int num) {
		// TODO Auto-generated method stub
		for (int  i= 0; i<arr.length ; i++) {
			if(num == arr[i]) {
				System.out.println("Found :- " + arr[i]);
				System.out.println("Comparisons done :- " + (iter+1));
				break;
			}
			iter++;
			
		}
		
		
		
		
	}

	public static void accpet(int[] arr) {
		
		Scanner sc = new Scanner(System.in);
		
		for (int i =0 ; i<arr.length ; i++) {
			System.out.println("Enter number");
			arr[i] = sc.nextInt();
		}
		
		
	}

	public static void Binarysearch(int[] arr, int start, int end, int num) {
		
		if(start<=end) {
			
			int mid = (start+end)/2;
			if(arr[mid]==num) {
				
				System.out.println("FOund :- " + arr[mid]);
				iter=iter+1;
				System.out.println("Comparisons done :- " + iter);
			}
			else if (arr[mid]<num) {
				iter=iter+1;
				Binarysearch(arr,mid+1, arr.length , num);
			}
			else {//if (arr[mid]>num) {
				iter=iter+1;
				Binarysearch(arr,0,mid-1,num);
				
			}
		}
		
		
	}
	

	
}
