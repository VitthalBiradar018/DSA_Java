package test;

import java.util.Scanner;

import service.ServiceSearch;

public abstract class TestSearch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int [] arr = new int[5];
		System.out.println("Enter NO to search");
		int num =sc.nextInt();
		ServiceSearch.accpet(arr);
		ServiceSearch.linearsearch(arr,num);
		//ServiceSearch.Binarysearch(arr,0,arr.length -1,num);
		
	}

}
