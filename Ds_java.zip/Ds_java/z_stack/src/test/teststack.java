package test;

import service.servicestack;

public class teststack {

	public static void main(String[] args) {
		servicestack s=new servicestack(5);
		s.push(5);
		s.push(10);
		s.push(15);
		s.push(20);
		s.push(35);
		System.out.println(s.pop());
		System.out.println(s.pop());
//		s.push(50);
//		s.display();
		
//		while(!s.isempty()) {
//			System.out.println(s.pop());
//
//	}
	}
}
