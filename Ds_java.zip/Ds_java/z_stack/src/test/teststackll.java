package test;

import service.servicestackll;

public class teststackll {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		servicestackll sll = new servicestackll();
		
//		sll.push(10);
//		sll.push(20);
//		sll.push(30);
//		sll.push(40);
		sll.display();
		
		System.out.println("========");
		sll.pop();
		sll.pop();
		sll.display();

	}

}
