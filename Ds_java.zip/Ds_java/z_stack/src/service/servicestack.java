package service;

public class servicestack {

	int [] arr;
	int top;
	public servicestack(int s) {
		super();
		arr = new int[s];
		top = -1;
	}
	public boolean isfull() {
		if(top == arr.length-1) {
			System.out.println("Stack is full");
		}
		return top == arr.length -1;
	}
	
	public boolean isempty() {
		if (top == -1) {
			System.out.println("stack is empty");
		}
		return top == -1;
	}
	public void push(int data) {
		if(!isfull()) {
			top ++;
			arr[top] = data;
			System.out.println("push vales  --> " +arr[top]);
		}
	}
	
	
	public int pop() {
		if(!isempty()) {
			int n =arr[top];
			top--;
			return n;
		}
		return -1;
	}
	public void display() {
		for(int i : arr) {
			System.out.print(i+ " ");
		}
	}
	
}
