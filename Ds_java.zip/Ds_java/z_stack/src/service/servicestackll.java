package service;

public class servicestackll {

	Node top = null;
	
	class Node {
		int top;
		Node next;
	
	public Node(int top) {
		this.top =top;
		next = null;
		
	}
	
  }
	public void push (int val) {
		Node newnode = new Node(val);
		if(top == null) {
			System.out.println("list is emepty created new --");
			top = newnode; 
			System.out.println("added");
		}
		else {
			newnode.next = top;
			top = newnode;
			System.out.println("added");
		}
	}
	public void pop () {
		Node temp = top;
		if(top == null) {
			System.out.println("list empty");
		}
		else {
			top = top.next;
			int n = temp.top;
			temp.next =null;
			temp =null;
			System.out.println(n);
			
		}
	}
	
	public void display () {
		for (Node temp = top ; temp !=null ; temp = temp.next) {
			System.out.print(temp.top+ " -->");
		}
		System.out.println();
	}
}
