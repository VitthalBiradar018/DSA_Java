package test;

import service.servicecll;

public class testcll {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		servicecll cll = new servicecll();
		
		cll.addatpos(10, 1);
		cll.addatpos(20, 2);
		cll.addatpos(30, 3);
		cll.addatpos(40, 4);
	//	cll.addatpos(50, 5);
		cll.display();
		System.out.println("===========");
		
	//	cll.deletebypos(2);
	//	cll.deletebypos(4);
	//	cll.display();

	}

}
