package service;

public class servicecll {

	Node head = null;
	Node last = null;
	
	class Node {
		int data;
		Node next;
		
		public Node (int data) {
			this.data = data;
			next = null;
		}
	}
	
	public void addatpos(int val , int pos) {
		Node newnode = new Node(val);
		Node temp = head;
		if(head == null) {
			System.out.println("list emmpty new addded");
			head = newnode;
			last = newnode;
			newnode.next =head;
		
		}
		else {
			if (pos == 1) {
				newnode.next = head;
				head = newnode;
				last.next = head;
			}
			else {
				for (int i = 0 ; i<=pos-2 && temp != last; i++) {
					temp = temp.next;
				}
				newnode.next = temp.next;
				temp.next = newnode;
				if(temp == last) {
					last = newnode;
					
				}
			}
		}
	}
	
	public void display() {
		Node temp;
		for ( temp = head; temp!=last ; temp = temp.next) {
			System.out.println(temp.data);
		}
		System.out.println(temp.data);
	}
	
	public void deletebypos(int pos) {
		Node temp =head;
		if(head == null ) {
			System.out.println("empty");
		}
		else {
			if(pos == 1) {
				if(head == last) {
				head = null;
				last =null;
				}else {
				last.next = head.next;
				head = temp.next;
				last = head;
				temp.next = null;
				temp = null;
				}
			}
			else {
				Node prev = null;
				for(int i = 0; i<pos -1 && temp!=last ; i++) {
					prev = temp;
					temp = temp.next;
					
				}
				if(temp!=last) {
				prev.next = temp.next;
//				temp.next = null;
//				temp =null;
				}
				if(temp == last) {
					//prev.next =head;
					last = prev;
					temp.next = null;
					temp =null;
					
				}
			}
		}
	}
}
