package service;

import java.util.Scanner;

public class Sorting_q {
//	. create a array of size 10 to store height of 10 students. Array is not sorted. 
//	Arrange the data in the sorted order using following techniques and find how many 
//	iterations are needed in each technique.
//	1. bubble sort
//	2. insertion sort
//	3. selection sort
	
	
	public void acceptData(int[] arr) {
		Scanner sc=new Scanner(System.in);
		for(int i=0;i<arr.length;i++) {
			System.out.println("Enter height at of student"+":"+(i+1));
			arr[i]=sc.nextInt();	
		}
	
	}
	
	public void display(int[] arr) {
		for(int i=0;i<arr.length;i++) {
			System.out.print(arr[i]+" ");
		}
		System.out.println("\n-------------");
	}
	
	public void bubbleSort(int[] arr) {
		boolean flag = false;
		int iteration=0;
		
		for(int i=0;i<arr.length;i++) {
			for(int j =1;j<arr.length-i;j++) {
				if(arr[j-1]>arr[j]) {
					flag=true;
					int temp=arr[j-1];
					arr[j-1]=arr[j];
					arr[j]=temp;
				}
			}
			//System.out.println("Iteration no.:" + i);
			iteration=iteration+1;
			if(!flag) {
				System.out.println("Sorted data");
				break;
			}
		}
		System.out.println("total Iterations are:"+iteration);
		
	}
	
	public void insertionSort(int[] arr) {
		int iteration=0;
		
		for(int i=1;i<arr.length;i++) {
			//value we want to insert into sorted portion
			int key=arr[i]; 
			//j is placed at end of sorted portion
			int j=i-1;
			while(j>=0 && arr[j]>key) {
				arr[j+1]=arr[j];
				j--;
			}
			iteration=iteration+1;
			arr[j+1]=key;
			
		}
		System.out.println("total Iterations are:"+iteration);
	}
	
	public void selectionSort(int[] arr) {
		int iteration=0;
		
		for(int i=0;i<arr.length;i++) {
			
			int minimum =arr[0];
			for(int j=0;j<arr.length;j++) {
				if(arr[j]<minimum) {
					minimum=arr[j];
				}
			}
			int temp = arr[i];
			arr[i]=minimum;
			minimum = temp;
			iteration=iteration+1;
			
		}
		System.out.println("total Iterations are:"+iteration);
	}
	
	public void heapSort(int[] arr){
		int iteration=0;
		int n = arr.length;
		for(int i=n/2-1;i>=0;i--){
			iteration=iteration+1;
		  heap(arr,n,i);
		}
		
		for(int i=n-1;i>=0;i--) {
			int temp=arr[0];
			arr[0]=arr[i];
			arr[i]=temp;
			iteration=iteration+1;
			heap(arr,i,0);
		}
		System.out.println("total Iterations are:"+iteration);
	}

	private void heap(int[] arr, int n, int i) {
		
		int largest=i;
		int left=2*i+1;
		int right=2*i+2;
		if(left<n && arr[left]>arr[largest])
			largest=left;
		if(right<n && arr[right]>arr[largest])
			largest=right;
		if(largest!=i) {
			int temp=arr[largest];
			arr[largest]=arr[i];
			arr[i]=temp;
			heap(arr,n,largest);
	}
	}
	
}
