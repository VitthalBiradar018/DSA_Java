package test;

import java.util.Scanner;

import service.Sorting_q;

public class Sorting_qTest {


	public static void main(String[] args) {
		Sorting_q st= new Sorting_q();
		int[] arr = new int[10];
		
		Scanner sc = new Scanner(System.in);
		st.acceptData(arr);
		
		System.out.println("Enter Choice to Which Type Of Sorting you want:");
		System.out.println("1.Bubble sort\n2.insertion sort\n3.selection sort\n4.heap sort");
		
		int choice=sc.nextInt();
		switch(choice) {
		case 1:
			st.bubbleSort(arr);
			st.display(arr);
			break;
		case 2:
			st.insertionSort(arr);
			st.display(arr);
			break;
		case 3:
			st.selectionSort(arr);
			st.display(arr);
			break;
		case 4:
			st.heapSort(arr);
			st.display(arr);
			break;
		default:
			System.out.println("Invalid choice:");
			break;
		
		}
sc.close();
	}

}
