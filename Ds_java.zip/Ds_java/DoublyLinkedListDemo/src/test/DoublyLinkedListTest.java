package test;

import service.DoublyLinkedList;

public class DoublyLinkedListTest {

	public static void main(String[] args) {
		DoublyLinkedList dl=new DoublyLinkedList();
		dl.addByPosition(1, 1);
		dl.addByPosition(2, 2);
		dl.addByPosition(3, 3);
		dl.addByPosition(4, 4);
		dl.addByPosition(6, 5);
		dl.displayList();
		dl.deleteBypos(2);
		dl.displayList();
		dl.displayListReverse();
	}

}
