package service;



public class DoublyLinkedList {

	public Node head=null;
	class Node{
		int data;
		Node prev;
		Node next;
		Node(){
			this.prev=null;
			this.next=null;
			
		}
		Node(int value){
			this.data=value;
			this.prev=null;
			this.next=null;
		}
		
		
	}
	
	public void addByPosition(int value,int pos) {
		Node newNode=new Node(value);
		if(head==null) {
			System.out.println("List is Empty \n new Node is Adding to List");
			head=newNode;
		}
		
		else if(pos==1){
			newNode.next=head;
			head=newNode;
		}
		else {
			Node temp=head;
			for(int i=0;temp!=null && i<pos-2;i++) {
				temp=temp.next;
			}
			if(temp!=null) {
				newNode.next = temp.next;
				if(temp.next!=null) {
					temp.next.prev=newNode;
				}
				newNode.prev=temp;
				temp.next=newNode;
			}
		}
	}
	
	public void deleteBypos(int pos) {
		if(head==null) {
			System.out.println("List is Empty");
		}
		
		Node temp=head;
		if(pos==1) {
			head=head.next;
			temp.next.prev=null;
			temp.next=null;
			temp=null;
		}
		else {
				for(int i=0;temp!=null && i<pos-1 ;i++) {
					temp=temp.next;
				}
				if(temp!=null) {
					temp.prev.next=temp.next;
					if(temp.next!=null) {
						temp.next.prev=temp.prev;
					}
					temp.next=null;
					temp.prev=null;
					temp=null;
				}
		}
	}
	public void displayList() {
		if(head==null) {
			System.out.println("List is Empty");
		}
		else {
			Node temp=head;
			while(temp!=null) {
				System.out.print(temp.data);
				temp=temp.next;
			}
		}
		System.out.println("\n----------------------------");
	}
	 public void displayListReverse() {
		  Node temp = head;
		  if(head==null) {
			  System.out.println("List is Empty");
		  }
		  else { 
			while(temp.next!=null) {
				temp=temp.next;
			}
			while(temp!=null) {
				System.out.print(temp.data+" ");
				temp=temp.prev;
			}
			  
		  }
		  System.out.println("\n----------------------------");
	  }
	 
}
