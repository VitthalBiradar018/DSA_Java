package test;

import service.Bfs;

public class bfsTest {

	public static void main(String[] args) {
		Bfs bfs = new Bfs(5);
		
		bfs.adjescencyList();
		bfs.display();
		bfs.bfsTraversal(1);

	}

}
