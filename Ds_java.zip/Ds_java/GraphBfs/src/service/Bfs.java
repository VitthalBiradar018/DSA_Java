package service;

import java.util.Scanner;



public class Bfs {
	Node[] heads;
	 public  Bfs(int num) {
  	  heads=new Node[num];
    }
	class Node{
		int data;
		Node next;
		
		public Node() {
			this.next=null;
		}
		public Node(int val) {
			this.data=val;
			this.next=null;
		}
	}
	
	public void adjescencyList() {
		Scanner sc = new Scanner(System.in);
		
		for(int i=0;i<heads.length;i++) {
			for(int j=0;j<heads.length;j++) {
				System.out.println(i+"--->"+j+":");
				int num = sc.nextInt();
				if(num==1) {
					Node node = new Node(j);
					if(heads[i]==null) {
						heads[i]=node;
					}
					else {
						node.next=heads[i];
						heads[i]=node;
					}
				}
			}
		}
	}
	
	public void display() {
		for(int i =0;i<heads.length;i++) {
			 System.out.print(" Node "+i+":");
			 for(Node temp=heads[i];temp!=null;temp=temp.next) {
  			  System.out.print(temp.data+"---->");
  			 
  		  }
			 System.out.println("null\n");
		}
	}
	
	public void bfsTraversal(int n) {
		QueueLL myQ = new QueueLL();
		myQ.enqueue(n);
		
		int[] bfsArr = new int[heads.length];
		int cnt=0;
		
		boolean[] visited = new boolean[heads.length];
		
		for(int i=0;i<heads.length;i++) {
		   visited[i]=false;
		}
		
		while(!myQ.isEmpty()) {
			int d = myQ.dequeue();
			if(!visited[d]) {
				visited[d]=true;
				
				bfsArr[cnt]=d;
				cnt++;
				
				for(Node temp = heads[d];temp!=null;temp=temp.next) {
					
					if(!visited[temp.data]) {
						myQ.enqueue(temp.data);
					}
				}
			}
		}
		 for(int n1:bfsArr) {
   		  System.out.print(n1+",");
   	  }
	}
}
