package test;

import service.GraphAdjecencyList;

public class GraphTest {

	public static void main(String[] args) {
		GraphAdjecencyList ga = new GraphAdjecencyList(5);
		
		ga.adjescencyList();
		ga.display();

	}

}
