package service;

public class LinkedListDemo {
	public Node head;
  class Node{
	  int data;
	  Node next;
	 public  Node(){
		   this.next=null;
	   }
	   
	   public Node(int val) {
		   this.data=val;
		   this.next=null;
	   }
  }
	
  public void addInPosition(int val, int pos) {
	  if(head==null) {
		  System.out.println("List is Empty");
	  }
	  else {
		 Node node = new Node(val);
		 
		 if(pos==1) {
			 node.next=head;
			 head=node;
		 }
		 else {
			 Node temp = head;
			 for(int i=0;temp!=null && i<pos-2;i++) {
					temp=temp.next;          
				}
			
			if(temp!=null) {
				 node.next=temp.next;
				 temp.next=node;
			}
	  }
  }
	
  }
  public void addFirst(int val) {
	  Node node = new Node(val);
		if(head==null) {
			head=node;
		}
		else {
			 Node temp = head;
			 while(temp.next!=null) {
					temp=temp.next;
				}
			 temp.next=node;
		}
}
  
  public void deleteByPosition(int pos) {
	  if(head==null) {
		  System.out.println("List is Empty");
		  
	  }
	  Node temp=head;
	  if(pos==1) {
		  head=temp.next;
		  temp.next=null;
		  temp=null;
	  }
	  else {
		 
		  Node prev=null;
		  for(int i=0;temp!=null&& i<pos-1;i++) {
			  prev=temp;
			  temp=temp.next;
		  }
		  if(temp!=null) {
			  prev.next=temp.next;
			  temp.next=null;
			  temp=null;
		  }
	  }
  }
  
  public void displayList() {
	  if(head==null) {
		  System.out.println("List is Empty");
	  }
	  else { Node temp = head;
		while(temp!=null) {
			System.out.println(temp.data+" ");
			temp=temp.next;
		}
		  
	  }
  }
 
}

