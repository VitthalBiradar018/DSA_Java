package test;
import service.LinkedListDemo;
public class LinkedListTest {

	public static void main(String[] args) {
		LinkedListDemo list=new LinkedListDemo();
		list.addFirst(1);
		list.addFirst(2);
		list.addFirst(3);
		list.addInPosition(4, 1);
		list.displayList();
		list.deleteByPosition(3);
		list.displayList();
	}

}
