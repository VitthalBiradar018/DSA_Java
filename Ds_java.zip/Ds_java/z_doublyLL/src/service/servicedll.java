package service;

public class servicedll {

	node head = null;
	
	class node {
		int data;
		node next;
		node prev;
		
		public node(int val) {
			data = val;
			next=  null;
			prev = null;
		}
	}
	
	public void addinpos(int val,int pos) {
		node newnode = new node(val);
		node temp = head;
		
		if (head == null) {
			System.out.println("List is empty");
			head = newnode;
		}
//		else {
//			if (pos)
//		}
	}
	
}
