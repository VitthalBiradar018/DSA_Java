package service;

public class StackArray{
 int[] arr;
 int top;
 
// public StackArray(int size) {
//	 this.arr=new T[size];
//	 
// }
//	
 public StackArray(int size) {
		super();
		this.arr = new int[size];
		this.top = -1;
	}
	public boolean isEmpty() {
		if(top==-1) {
			System.out.println("Stack is Empty now");
		}
		return top==-1;
	}
	
	

	public boolean isFull() {
		if(top==arr.length-1) {
			System.out.println("Stack Overlow");
		}
		return top==arr.length-1;
	}
	
	public void push(int val) {
		if(!isFull()) {
			top++;
			arr[top]=val;
		}
	}
	
	public int pop() {
		if(!isEmpty()) {
			int num = arr[top];
			top--;
			return num;
		}
		
		return -1;
	}
	
	public void display() {
		for(int i = arr.length-1;i>=0;i--) {
			System.out.println(arr[i]);
		}
		System.out.println("\n-----------------");
	}
}
