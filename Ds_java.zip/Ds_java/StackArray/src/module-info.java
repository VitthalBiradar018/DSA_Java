/**
 * 
 */
/**
 * @author IET
 *
 */
module StackArray {
}