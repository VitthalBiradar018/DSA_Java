package test;

import service.StackArray;

public class StackArrayTest {

	public static void main(String[] args) {
	  StackArray st = new StackArray(5);
	  
	  st.push(1);
	  st.push(2);
	  st.push(3);
	  st.push(4);
	  st.push(5);
	  st.display();
	  st.push(6);
	  st.pop();
	  st.push(6);
	  st.display();
	  st.pop();
	  st.pop();
	  st.pop();
	  st.pop();
	  st.pop();
	  st.pop();

	}

}
