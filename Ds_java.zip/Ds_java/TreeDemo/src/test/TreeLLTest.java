package test;

import service.TreeLL;

public class TreeLLTest {

	public static void main(String[] args) {
		TreeLL tr = new TreeLL();
		
		tr.insertKey(64);
		tr.insertKey(33);
		tr.insertKey(32);
		tr.insertKey(91);
		tr.insertKey(123);
		tr.inorder();
		System.out.println();
		
		tr.search(91);
		tr.search(12345);

	}

}
