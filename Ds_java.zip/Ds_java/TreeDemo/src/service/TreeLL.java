package service;

public class TreeLL {

	Node root;
	public TreeLL() {
		root=null;
	}
	
	class Node{
		int data;
		Node left,right;
		
		public Node() {
			this.left=null;
			this.right=null;
		}
		public Node(int val) {
			this.data=val;
			this.left=null;
			this.right=null;
		}
	}
	
	public void insertKey(int val) {
		root=insertData(root,val);
	}

	private Node insertData(Node root, int val) {
		Node newNode = new Node(val);
		
		if(root==null) {
			root=newNode;
			return root;
			
		}
		
		else {
			if(val<root.data) {
				root.left=insertData(root.left,val);
			}else {
				root.right=insertData(root.right,val);
			}
			return root;
		}
	
	}
	
	public void inorder() {
		inorderTraversal(root);
	}

	private void inorderTraversal(Node root) {
		if(root!=null) {
		   inorderTraversal(root.left);
		   System.out.print(root.data+ " ");
		   inorderTraversal(root.right);
		}
		
		
	}
	
	public void search(int val) {
		boolean find=searchInTree(root,val);
		if(find) {
			System.out.println("Found it");
		}
		else {
			System.out.println("Not Found");
		}
	}
	private boolean searchInTree(Node root, int val) {
		if(root==null) {
			return false;
		}
		else {
		if(root.data==val) {
			return true;
		}
		else {
			if(val<root.data) {
				return searchInTree(root.left, val);
			}
			else {
				return searchInTree(root.right, val);
			}
		}
		}
	}
}
