package test;

import service.ArrService;

public class ArrTest {

	public static void main(String[] args) {
		int [] arr = new int [5];
		
		ArrService. accept(arr);
		ArrService.display(arr);
		ArrService.arrcheck(arr);
		

	}

}
