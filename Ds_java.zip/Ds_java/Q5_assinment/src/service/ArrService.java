package service;

import java.util.Scanner;

public class ArrService {

	public static void accept(int[]arr) {
		Scanner sc = new Scanner(System.in);
		
		for(int i = 0 ; i < arr.length ; i++) {
			System.out.println("Enter Number");
			arr[i]= sc.nextInt();
		}
	}
	
	public static void arrcheck(int [] arr) {
		Scanner sc = new Scanner(System.in);
		System.out.println("\nenter Number to search");
		int num = sc.nextInt();
		int cnt =0;
		int n =0; 
		for(int i = 0; i<arr.length ; i++) {
			if(arr[i] == num) {
				cnt++;
				
				n = arr[i];
						//System.out.println("Number Found : -" + arr[i]);
				
			}
			
		}System.out.println("Number Found : -" + n);
		System.out.println(cnt + " duplicates");
	}
	public static void display(int [] arr) {
		for (int i = 0 ; i<arr.length ; i++) {
			System.out.print(arr[i]  + " ");
		}
	
	}
}
