package test;

import service.hashtablee;

public class hashtest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		hashtablee ht = new hashtablee(5);
		ht.insertvalue(10);
		ht.insertvalue(20);
		ht.insertvalue(56);
		ht.insertvalue(32);
		
		
		ht.display();
		ht.search(2);
	}

}
