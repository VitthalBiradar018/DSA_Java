package service;

public class hashtablee {

	Node [] head;

	class Node {
		int data;
		Node next;
		
		Node(int val){
			data =val;
			next = null;
		}
	}
	public hashtablee(int size){
		head = new Node[size];	
		
		for (int i = 0; i<head.length ; i++) {
			head [i] = null;
		}
	}
	
	public void insertvalue(int val){
		Node newnode = new Node(val);
		int d = val%head.length;
		
		if(head[d] == null) {
			head[d] = newnode;
		}
		else {
			newnode.next = head [d];
			head[d] = newnode;
		}
	}
	
	public boolean search(int data) {
		int d = data%head.length;
		if(head[d]==null) {
			System.out.println("Bucket empty");
			return false;
		}
		else {
		
			for (Node temp = head[d]; temp!=null ; temp = temp.next) {
				
				
				if(temp.data == data) {
					System.out.println("FOund :- " + temp.data);
					temp = temp.next;
					return true;
				}
			}
		}
		System.out.println("Not found");
		return false;
	}
	
	public void display() {
		for(int i=0;i<head.length;i++) {
			System.out.print(i+"---->");
			for(Node temp=head[i];temp!=null;temp=temp.next) {
				System.out.print(temp.data+"--->");
			}
			System.out.println();
		}
	}
}
