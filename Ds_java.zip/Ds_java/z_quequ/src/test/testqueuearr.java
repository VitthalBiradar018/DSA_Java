package test;

import service.servicequequarr;

public class testqueuearr {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		servicequequarr q = new servicequequarr(5);
		
		q.enqueue(10);
		q.enqueue(20);
		q.enqueue(30);
		q.enqueue(30);
	//	q.enqueue(30);
	//	q.enqueue(30);
		q.display();
		System.out.println("=========");
		q.dequeue();
		q.display();
	}

}
