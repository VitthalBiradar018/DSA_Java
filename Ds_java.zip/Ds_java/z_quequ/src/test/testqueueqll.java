package test;

import service.queuell;

public class testqueueqll {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		queuell qll = new queuell();
		qll.enqueue(10);
		qll.enqueue(20);
		qll.enqueue(30);
		qll.enqueue(40);
		qll.display();
		
		qll.dequeue();
	}

}
