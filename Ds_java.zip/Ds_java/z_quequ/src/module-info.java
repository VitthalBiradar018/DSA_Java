/**
 * 
 */
/**
 * @author IET
 *
 */
module z_quequ {
}