package service;

public class servicequequarr {

	int [] arr;
	int front;
	int rear;
	
	public servicequequarr(int size) {
		arr = new int [size];
		front = -1;
		rear = -1;
	}
	
	public boolean isempty() {
		if (front == -1) {
			System.out.println("Queue is Empty");
			return true;
		}
		return false;
	}
	
	public boolean isfull() {
		if(rear == arr.length-1) {
			System.out.println("Queue is Full");
			return true;
		}
		return false ;
	}
	
	public void enqueue (int data) {
		 
		if(!isfull()){
			rear++;
			arr[rear] = data;
			if(front == -1) {
			front++;
			}
		}
		else 
			System.out.println("queque full");
		
	}
	public void dequeue() {
		if(!isempty()) {
			int n = arr[front];
			System.out.println(n);
			front++;
			if(front == arr.length) {
				System.out.println("queue is full");
				
		}
			System.out.println("\n-----------");
			int temp= front;
			for(;temp!=arr.length;temp++) {
				System.out.println(arr[temp]);
			}
			System.out.println("\n-----------");
		}
		}
	
	public void display() {
		for(int i: arr) {
			System.out.print(i + " ");
		}
		System.out.println();
	}
}
