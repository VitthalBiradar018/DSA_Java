package service;

public class queuell {

	Node front = null;
	Node rear = null;
	
	class Node {
		int data;
		Node next;
		
		public Node(int val) {
			data= val;
			next = null;
		}
	}
	
	public void enqueue(int val) {
		Node newnode = new Node(val);
		if(front == null) {
			System.out.println("queque is empty");
			front = newnode;
			rear = newnode;
		}
		else {
			rear.next = newnode;
			rear = newnode;
		}
	}
	
	public int dequeue() {
		int n = rear.data;
		System.out.println(n);
		if(front == rear) {
			front = null;
			rear = null;
		}
		else {
			Node temp = front;
			front = front.next;
			temp.next = null;
			temp = null;
		}
		return n;
	}
	
	public void display() {
		Node temp = front;
		for(; temp!=null; temp = temp.next) {
			System.out.print(temp.data + ",");
		}
		System.out.println("\n----------------------------\n");
	}
}
