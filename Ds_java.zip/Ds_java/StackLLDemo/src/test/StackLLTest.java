package test;

import service.StackLL;

public class StackLLTest {

	public static void main(String[] args) {
		StackLL<Integer> st = new StackLL<>();
		
		st.push(18);
		st.push(4);
		st.push(55);
		st.display();
		st.pop();
		st.display();

	}

}
