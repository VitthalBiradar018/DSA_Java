package service;
import java.util.Scanner;
public class servicesort {

	public static void bubblesort(int[] arr) {
		
		for(int i = 0; i<arr.length ; i++) {
			for (int  j =0; j<arr.length -1 ;j++) {
				if(arr[j]>arr[j+1]) {
					int temp = arr[j];
					arr[j] = arr[j+1];
					arr[j+1] = temp;
				}
			}
		}
		
	}

	public static void accept(int [] arr) {
		Scanner sc = new Scanner(System.in);
		for (int i = 0 ; i<arr.length ; i++) {
			System.out.println("Enter Values");
			arr[i]=sc.nextInt();
		}
		
	}

	public static void display(int[] arr) {
		for (int i =0 ; i<arr.length ; i++) {
			System.out.print(arr[i] + " ");
		}
		System.out.println();
	}

	public static void selectionsort(int[] arr) {
		
		for (int i = 0; i<arr.length ;i++) {
			for (int j = i; j<arr.length ; j++) {
			
			if(arr[i]>arr[j]) {
				int temp = arr[i];
				arr[i]= arr[j];
				arr[j] = temp;
			}
			}
		}
		
	}

	public static void selesort(int[] arr) { //madam paddat
		
		for (int i = 0; i<arr.length ; i++) {
			int minno = findmin(arr,i,arr.length);
			int temp = arr[i];
			arr[i]= arr[minno];
			arr[minno] = temp;
		}
	}

	private static int findmin(int[] arr, int start, int end) {
		int minno = arr[start];
		int minidx=start;
		for (int i = start ; i<end ; i++) {
			if(minno>arr[i]) {
				minno =arr[i];
				minidx=i;
			}
		}
		return minidx;
	}

}
