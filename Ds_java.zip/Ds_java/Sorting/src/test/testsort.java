package test;

import java.util.Scanner;

import service.servicesort;

public class testsort {

	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		System.out.println("Enter size of Array");
		int size = sc.nextInt();
		int [] arr = new int[size];
		
		servicesort.accept(arr);
		servicesort.display(arr);
//		System.out.println("=================bubble sort ==============");
//		servicesort.bubblesort(arr);
//		servicesort.display(arr);
		System.out.println("=================Selection sort ============");
		//servicesort.selectionsort(arr);
		servicesort.selesort(arr); //madam padat
		servicesort.display(arr);
		

	}

}
