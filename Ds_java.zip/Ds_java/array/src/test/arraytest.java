package test;

import java.util.Scanner;
import service.arrayservice;
public class arraytest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner (System.in);
		
		System.out.println("enter size");
		int num = sc.nextInt();
		
		int [] arr = new int[num];
		arrayservice.acceptdata(arr);
//arrayservice.display(arr);
//		
//		arrayservice.maxnum(arr);
//		arrayservice.maxeven(arr);
//arrayservice.reverseArray(arr, 0, arr.length);
//arrayservice.display(arrayservice.rotatearray(arr));

	//arrayservice.sumofall(arr);
	arrayservice.sumofdigits(arr);
//	int num1 = arrayservice.binarysearch(arr,0,arr.length,4);
//	System.out.println("searched value " +num1);
	}

}
