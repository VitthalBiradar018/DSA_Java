package service;

import java.util.Scanner;

public class arrayservice {
	
	
	public static void acceptdata(int[] arr) {
		Scanner sc = new Scanner(System.in);
		// TODO Auto-generated method stub
		for (int i = 0; i<arr.length ; i++) {
		System.out.println("Enter array elemnts ");
			arr[i]= sc.nextInt(); 
		}
	}
	public static void display(int [] arr) {
		// TODO Auto-generated method stub
		for (int i = 0 ; i<arr.length; i++) {
			System.out.print(arr[i]+" ");
		}
	}
	public static void maxnum(int [] arr) {
		// TODO Auto-generated method stub
		int max =arr[0];
		for (int i = 0; i<arr.length ; i++) {
			if (arr[i]>max) { 
				max = arr[i];
				
			}
		}
		System.out.println("MAX number " +max);
	}
	public static void maxeven(int[] arr) {
		// TODO Auto-generated method stub
		int max = arr[0];
		for (int i = 0 ; i<arr.length ; i++) {
			
			if (arr[i]%2 == 0 && arr[i]>max) {
				max = arr[i];
			}
			
		}
		 if(max%2 != 0) {
			System.out.println("Not Even number");
		}
		 else 
			 System.out.println("even max" + max);
		
	}
	
	private static int[] reverseArray(int[] arr,int i,int j) {
		
		while(i<=j) {
			
			int temp = arr[i];
			arr[i] = arr[j];
			arr[j] = temp;
			i++;
			j--;
		}
		return arr;
	}
	public static int[] rotatearray(int[] arr) {
		Scanner sc = new Scanner(System.in);
System.out.println("Enter no to rotate array");

		int k=sc.nextInt();
	
		int r = k%arr.length;
		
		
		reverseArray(arr, 0, arr.length-1);
		reverseArray(arr, 0, r-1);
		reverseArray(arr, r, arr.length-1);
		return arr;
		
	}
	public static int binarysearch(int[] arr, int i, int length, int num) {
		// TODO Auto-generated method stub
		if(i<=length) 
		{
			int mid = (length+i)/2;
			
			if (arr[mid] == num) 
			{
				return arr[mid];
			}
			else 
			{ 
				if (num<arr[mid])
				{
					return binarysearch(arr,0,mid-1,num);
				}
				else 
				{
					return binarysearch(arr,mid+1,length,num);
				}
			}
		}
		else
		{
			return -1;
		}
	}
	public static void sumofall(int[] arr) {
		// TODO Auto-generated method stub
		int sum = 0;
		for ( int i = 0 ; i<arr.length ;i++) {
			sum += arr[i];
		}
		System.out.println(sum);
	}
	public static void sumofdigits(int[] arr) {
		// TODO Auto-generated method stub
		int total = 0;
		for (int i = 0 ; i < arr.length ;i++) {
			int rem=0;
			int num = arr[i];
			while(num>0) {
			rem = num%10; //27 == 7
			
			total = total + rem;
			num = (int)num/10;
			
			}
			System.out.println(  "sum - " + total);
		}
	}
	
}
		
	
	
	

