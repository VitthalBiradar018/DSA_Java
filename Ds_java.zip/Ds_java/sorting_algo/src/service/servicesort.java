package service;

import java.util.Scanner;

public class servicesort {
	public static void accept(int [] arr) {
		Scanner sc = new Scanner(System.in);
		for (int i = 0 ; i<arr.length ; i++) {
			System.out.println("Enter Values");
			arr[i]=sc.nextInt();
		}
		
	}

	public static void display(int[] arr) {
		for (int i =0 ; i<arr.length ; i++) {
			System.out.print(arr[i] + " ");
		}
		System.out.println();
	}

	public static void insertion(int[] arr) {
		
		for (int i = 1 ; i<arr.length ; i++) {
			int current = arr[i];
			int j = i-1;
			
			while(j>=0 &&  arr[j]>current) {
				arr[j+1]=arr[j];
				
				j--;
			}
			arr[j+1] =current;
		}
		
		
		
		
	}

	public static void heapSort(int[] arr) {
		int n= arr.length;
		for(int i=n/2-1;i>=0;i--) {
			maxheap(arr,n,i);
		}
		
		for(int i=n-1;i>=0;i--) {
			int temp = arr[0];
			arr[0]=arr[i];
			arr[i]=temp; 
			
			maxheap(arr, i, 0);
		}
		display(arr);
		
	}

	private static void maxheap(int[] arr, int n, int i) {
		
	 int largest = i;
	 int left = 2*i+1;
	 int right = 2*i+2;
	 
	 if(left<n && arr[left]>arr[largest]) {
		 largest=left;    
	 }
	 if(right<n && arr[right]>arr[largest]) {
		 	largest=right;
	 }
	 if(largest!=i) {
		 int temp = arr[largest];
		 arr[largest]=arr[i];
		 arr[i]=temp;
		 maxheap(arr, n, largest);
	 }
	 
		
	}
}
