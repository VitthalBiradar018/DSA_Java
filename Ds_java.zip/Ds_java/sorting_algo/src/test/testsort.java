package test;

import service.servicesort;

public class testsort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] arr = new int [5];
		
		servicesort.accept(arr); 
		
		//servicesort.insertion(arr);
		servicesort.display(arr);
		servicesort.heapSort(arr);
		
	}

}
