package service;

import java.util.Scanner;

public class servicesort {
	public static void accept(int [] arr) {
		Scanner sc = new Scanner(System.in);
		for (int i = 0 ; i<arr.length ; i++) {
			System.out.println("Enter Values");
			arr[i]=sc.nextInt();
		}
		
	}

	public static void display(int[] arr) {
		for (int i =0 ; i<arr.length ; i++) {
			System.out.print(arr[i] + " ");
		}
		System.out.println();
	}

	public static void quicksort(int[] arr, int s, int end) {
		if(s<end) {
		int par = partition (arr,s,end);
		quicksort(arr,s,par-1);
		quicksort(arr,par+1,end);
		}
		
	}

	private static int partition(int[] arr, int s, int end) {
		int pivot = s;
		int i = s;
		int j = end;
		
		while(i<j) {
			while (i<end && arr[i]<=arr[pivot]) {
				i++;
			}
			while (j > pivot && arr[j]>arr[pivot]  ) {
				j--;
			}
			if(i<j) {
			int t = arr[i];
			arr[i] = arr[j];
			arr[j] = t;
		}
		}	
		
			int t = arr[j];
			arr[j] = arr[pivot];
			arr[pivot] = t;
		
		
		return j;
	}

	
	
	
	public static void mergesort(int[] arr, int s, int e) {
		if (s<e) {
			int mid = (s+e)/2;
			
			mergesort(arr,s,mid);
			mergesort(arr,mid+1,e);
			merge(arr,s,mid,e);
		}
		
	}

	private static void merge(int[] arr, int s, int mid, int e) {
		int n1 = mid - s+1;
		int n2 = e-mid;
		
		int [] left = new int[n1];
		int [] right = new int [n2];
		
		for (int i =0;i<n1;i++ ) {
			left[i] = arr[s+i];
		}
		for(int i = 0; i<n2 ;i++) {
			right[i]= arr[mid+1+i];
		}
		int i = 0;
		int j= 0;
		int k = s;
		
		while (i<n1 && j<n2 ) {
			
			if(left[i]<=right[j]) {
				arr[k]=left[i];
				i++;
				k++;
			}
			else {
				arr[k]=right[j];
				j++;
				k++;
			}
		}
		while (i<n1) {
			arr[k]= left[i];
			i++;
			k++;
		}
		while (j<n2) {
			arr[k]= right[j];
			j++;
			k++;
		}
		
	}


}
