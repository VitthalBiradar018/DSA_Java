package test;

import service.servicesort;

public class testsort {

	public static void main(String[] args) {
	
		int [] arr = new int [5];
		
		servicesort.accept(arr);
		//servicesort.display(arr);
		//servicesort.quicksort(arr,0,arr.length-1);
		servicesort.mergesort(arr,0,arr.length-1);
		servicesort.display(arr);
	}

}
