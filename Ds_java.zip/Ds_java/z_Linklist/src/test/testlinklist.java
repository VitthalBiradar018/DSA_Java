package test;

import service.servicelinklist;

public class testlinklist {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		servicelinklist lst = new servicelinklist(); 
		//lst.addfirst(10); 
		lst.addbetween(5, 1);
		lst.addbetween(20,2);
		lst.addbetween(30,3);
		lst.addbetween(100, 1);
		lst.addbetween(60,2);
		lst.addbetween(70,5);
		lst.display();
		//lst.addlast(30);
		System.out.println();
		
		lst.deleteany(2);
		lst.deleteany(1);
		lst.display();
		
		

	}

}
