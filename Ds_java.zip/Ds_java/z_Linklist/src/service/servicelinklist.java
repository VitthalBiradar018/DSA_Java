package service;

public class servicelinklist {
	
	public Node head =null;
	class Node {
		int data;
		Node next;
		
		public Node(){
			next = null;
		}
		public Node(int val) {
			data = val;
			next = null;
		}	
	}
	
	public void addfirst(int val) {
		Node newnode = new Node(val);
		if(head == null) {
			 head = newnode;
		}
		else 
			System.out.println(" do add at second position");
	}
	
	public void addbetween(int val, int pos) {
		Node node = new Node(val);
		if(head==null) {
			  System.out.println("List is Empty");
			  head=node;
		  }
		  else {
			 
			 
			 if(pos==1) {
				 node.next=head;
				 head=node;
			 }
			 else {
				 Node temp = head;
				 for(int i=0;temp!=null && i<pos-2;i++) {
						temp=temp.next;          
					}
				
				if(temp!=null) {
					 node.next=temp.next;
					 temp.next=node;
				}		  
		
			 }
		  }
	
	}
//	public void addlast(int val) {
//		Node newnode = new Node(val);
//		Node temp = head;
//		if(temp.next == null) {
//			temp.next = newnode;
//			
//		}
//	}
	
	public void deleteany(int pos) {
	
		Node temp = head;
		if (head==null) {
			System.out.println("EMpty lsit");
		}
		else  {
			if(pos == 1) {
				
				head = temp.next;
				temp.next = null;
				temp = null;
			}
			else {
				Node prev = null;
				for (int i=0; i<pos-1 && temp != null ; i++) {
					prev = temp;
					temp = temp.next;
				}
				if(temp!=null) {
					prev.next = temp.next;
					temp.next =null;
					temp = null;
				}
			}
		}
	}
	
	public void display() {
		Node temp = head;
		if (head == null) {
			System.out.println("empty list");
		}
		else {
			while(temp!=null) {
			System.out.println(temp.data + " ");
			temp = temp.next;
			}
		}
	}
}
