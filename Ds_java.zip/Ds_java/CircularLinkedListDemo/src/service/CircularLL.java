package service;



public class CircularLL {
	public Node head=null;
	Node last=null;
	class Node{
		int data;
		Node next;
		
		 public  Node(){
			   this.next=null;
		   }
		   
		   public Node(int val) {
			   this.data=val;
			   this.next=null;
		   }
		
	}
	
	public void addInPosition(int val, int pos) {
		
	Node newNode = new Node(val);
		  if(head==null) {
			  System.out.println("List is Empty value is added");
			  head=newNode;
			  last=newNode;
			  newNode.next=head;
		  }
		  else {
			 
			 if(pos==1) {
				 newNode.next=head;
				 head=newNode;
				 last.next=head;
			 }
			 else {
				 Node temp = head;
				 for(int i=0;temp!=last && i<pos-2;i++) {
						temp=temp.next;          
					}
				
				if(temp!=null) {
					
					newNode.next=temp.next;
					temp.next=newNode;
					if(temp==last) {
						last=newNode;
						
					}
					
				}
		  }
	  }
	}
	
	 public void deleteByPosition(int pos) {
		  if(head==null) {
			  System.out.println("List is Empty");
			  
		  }
		  else {
		  Node temp=head;
		  if(pos==1) {
			  
		  if(head==last) {
			head=null;
			last=null;
		  }else {
			  last.next=head.next;
			  head=head.next;
			  temp.next=null;
			  temp=null;
		  }
		  }
		  
		  else {
			 
			  Node prev=null;
			  for(int i=0;temp!=null&& i<pos-1;i++) {
				  prev=temp;
				  temp=temp.next;
			  }
			  if(temp!=null) {
				  prev.next=temp.next;
				  if(temp==last)
					  last=prev;
				  temp.next=null;
				  temp=null;
			  }
		  }
	  }
}
	 
	 public void display() {
		 if(head==null) {
			 System.out.println("List is Empty");
		 }
		 else {
			 Node temp=head;
			 for(;temp!=last;temp=temp.next) {
				 System.out.print(temp.data+"->");
			 }
			 System.out.print(temp.data+"->"+temp.next.data);
			 System.out.println("\n-----------------");
		 }
	 }
}
