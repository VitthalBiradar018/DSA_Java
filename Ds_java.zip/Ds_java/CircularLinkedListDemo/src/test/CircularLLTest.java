package test;

import service.CircularLL;

public class CircularLLTest {

	public static void main(String[] args) {
		CircularLL cl=new CircularLL();
		
		cl.addInPosition(1, 1);
		cl.addInPosition(2, 2);
		cl.addInPosition(3, 1);
		cl.addInPosition(4, 2);
		cl.display();
		cl.deleteByPosition(4);
		cl.display();
		cl.addInPosition(5, 4);
		cl.display();
		cl.addInPosition(6, 3);
		cl.deleteByPosition(1);
		cl.display();
	}

}
