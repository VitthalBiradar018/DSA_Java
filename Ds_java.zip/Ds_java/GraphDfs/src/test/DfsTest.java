package test;

import service.Dfs;

public class DfsTest {

	public static void main(String[] args) {
		Dfs df = new Dfs(5);
		df.adjescencyList();
		df.display();
		df.dfsTraversal(0);

	}

}
