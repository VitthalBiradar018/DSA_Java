package service;

import java.util.Scanner;



public class Dfs {

	Node[] heads;
	 public  Dfs(int num) {
   	  heads=new Node[num];
     }
	class Node{
		int data;
		Node next;
		
		public Node() {
			this.next=null;
		}
		public Node(int val) {
			this.data=val;
			this.next=null;
		}
	}
	
	public void adjescencyList() {
		Scanner sc = new Scanner(System.in);
		
		for(int i=0;i<heads.length;i++) {
			for(int j=0;j<heads.length;j++) {
				System.out.println(i+"--->"+j+":");
				int num = sc.nextInt();
				if(num==1) {
					Node node = new Node(j);
					if(heads[i]==null) {
						heads[i]=node;
					}
					else {
						node.next=heads[i];
						heads[i]=node;
					}
				}
			}
		}
	}
	
	public void display() {
		for(int i =0;i<heads.length;i++) {
			 System.out.print(" Node "+i+":");
			 for(Node temp=heads[i];temp!=null;temp=temp.next) {
   			  System.out.print(temp.data+"---->");
   			 
   		  }
			 System.out.println("null\n");
		}
	}
	
	public void dfsTraversal(int n) {
		StackLL<Integer> stack = new StackLL<>();
		
		stack.push(n);
		
		int[] mydfs = new int[heads.length];
		
		int cnt=0;
		boolean[] visitedArray=new boolean[heads.length];
		
		for(int i=0;i<visitedArray.length;i++) {
			visitedArray[i]=false;
		}
		
		while(!stack.isEmpty()) {
			int d = stack.pop();
			
			if(!visitedArray[d]) {
				visitedArray[d]=true;
				
				mydfs[cnt]=d;
				cnt++;
				
				for(Node temp=heads[d];temp!=null;temp=temp.next) {
					if(!visitedArray[temp.data]) {
						stack.push(temp.data);
					}
				}
			}
		}
		 for(int n1:mydfs) {
   		  System.out.print(n1+",");
   	  }
	}
}
