package service;

public class StackLL<T>{

	Node top;
	public StackLL() {
		top=null;
	}
	
	class Node{
		T data;
		Node next;
		
		public Node() {
			this.next=null;
		}
		public Node(T val) {
			this.data=val;
			this.next=null;
		}
	}
	
	public boolean isEmpty() {
		return top==null;
	}
	
	public void push(T val) {
		Node newNode = new Node(val);
		
		if(isEmpty()) {
			System.out.println("Stack is Epmty adding in Stack:");
			top=newNode;
		}
		else {
			newNode.next=top;
			top=newNode;
		}
	}
	
	public T pop() {
		if(isEmpty()) {
			System.out.println("Stack is Empty:");
		}
		else {
			T value=top.data;
			Node temp=top;
			top=temp.next;
			temp.next=null;
			temp=null;
			
			return value;
		}
		return null;
		
	}
	
	public void display() {
		if(isEmpty()) {
			System.out.println("Stack is Empty");
		}
		
		else {
			Node temp=top;
			for(;temp!=null;temp=temp.next) {
				System.out.println(temp.data);
			}
			
			System.out.println("\n-------------------");
		}
	}
}
